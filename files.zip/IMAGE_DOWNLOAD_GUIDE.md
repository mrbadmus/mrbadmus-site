# MrBadmusAI — Biology Image Download Guide
## How to set up

1. In your repo (`/Users/midebadmus/Documents/GitHub/mrbadmus-site`), create this folder:
   ```
   mrbadmus_site/images/biology/
   ```

2. Download each image below and save it with the **exact filename** listed.

3. After downloading all images, run:
   ```bash
   cd /Users/midebadmus/Documents/GitHub/mrbadmus-site
   python3 generate_site_v4.py
   ```

4. Commit and push via GitHub Desktop.

---

## Images to Download

### 1. Animal vs Plant Cell
- **Filename:** `animal-plant-cell.png`
- **Used on:** Cell Biology → Animal, Plant and Prokaryotic Cells
- **Best source:** OpenStax Biology 2e, Figure 4.8
  - Go to: https://openstax.org/books/biology-2e/pages/4-3-eukaryotic-cells
  - Right-click the figure showing "(a) a typical animal cell and (b) a typical plant cell" → Save Image As → `animal-plant-cell.png`
- **Alt source (simpler):** https://commons.wikimedia.org/wiki/File:Animal_cell_structure_en.svg
  - Click the image → Download as PNG → rename to `animal-plant-cell.png`
- **Licence:** CC BY 4.0 (OpenStax) / Public Domain (Wikimedia)

### 2. Transport Across Membranes (Diffusion, Osmosis, Active Transport)
- **Filename:** `transport-across-membranes.png`
- **Used on:** Cell Biology → Diffusion, Osmosis and Active Transport
- **Best source:** Search Wikimedia for a combined diagram, or use:
  - https://commons.wikimedia.org/wiki/File:Scheme_facilitated_diffusion_in_cell_membrane-en.svg
  - Or search "osmosis diffusion active transport diagram" on https://openstax.org/books/biology-2e/pages/5-2-passive-transport
- **Licence:** CC BY 4.0

### 3. Mitosis Stages
- **Filename:** `mitosis-stages.png`
- **Used on:** Cell Biology → Cell Division — Mitosis and Stem Cells
- **Best source:** OpenStax Biology 2e, Figure 10.6 or similar
  - Go to: https://openstax.org/books/biology-2e/pages/10-2-the-cell-cycle
  - Find the mitosis stages diagram → Save as `mitosis-stages.png`
- **Alt source:** https://commons.wikimedia.org/wiki/File:Mitosis_Stages.svg
- **Licence:** CC BY 4.0

### 4. Enzyme Lock and Key Model
- **Filename:** `enzyme-lock-key.png`
- **Used on:** Organisation → Enzymes and Digestion
- **Best source:** Wikimedia Commons
  - https://commons.wikimedia.org/wiki/File:Induced_fit_diagram.svg
  - Or search: "lock and key enzyme model diagram"
- **Licence:** CC BY-SA 4.0

### 5. Heart Structure
- **Filename:** `heart-structure.png`
- **Used on:** Organisation → The Heart and Circulatory System
- **Best source:** OpenStax Anatomy & Physiology
  - https://openstax.org/books/anatomy-and-physiology-2e/pages/19-1-heart-anatomy
  - Find the labelled heart diagram with chambers → Save as `heart-structure.png`
- **Alt source:** https://commons.wikimedia.org/wiki/File:Diagram_of_the_human_heart_(cropped).svg
- **Licence:** CC BY 4.0

### 6. Photosynthesis
- **Filename:** `photosynthesis.png`
- **Used on:** Bioenergetics → Photosynthesis
- **Best source:** OpenStax Biology 2e
  - https://openstax.org/books/biology-2e/pages/8-1-overview-of-photosynthesis
  - Find the overview diagram → Save as `photosynthesis.png`
- **Alt source:** https://commons.wikimedia.org/wiki/File:Photosynthesis_en.svg
- **Licence:** CC BY 4.0

### 7. Reflex Arc
- **Filename:** `reflex-arc.png`
- **Used on:** Homeostasis and Response → The Nervous System
- **Best source:** Wikimedia Commons
  - https://commons.wikimedia.org/wiki/File:Reflex_arc.svg
  - Or search "reflex arc diagram labelled"
- **Licence:** CC BY-SA 4.0

---

## Notes
- All images go in: `mrbadmus_site/images/biology/`
- Images will render inside a white card on the dark theme, so white-background images work fine
- Attribution is automatically shown below each image on the site
- You can add more images later by adding a `"diagram"` field to any subtopic in `all_subtopics_biology.py`
- The same system works for Chemistry and Physics — just create `/images/chemistry/` and `/images/physics/` folders

## Diagram field format (for future reference)
```python
"diagram": {
    "title": "Diagram Title",
    "src": "/images/biology/filename.png",
    "alt": "Description for accessibility",
    "caption": "Caption text shown below the image",
    "attribution": "Image: Source Name, CC BY 4.0"
},
```
